+++
title="waz"
description="a basic demo of zola. Does it work? This old man, he played one. He played knick knack on my drum."
date=2019-03-27

[taxonomies]
tags = ["rust", "test", "zola"]
categories = ["programming", "misc.", "programming languages"]

[extra]
+++

# Hello Hello

Lorem ipsum dolor sit amet, consectetuer adipiscing elit.  Donec hendrerit
tempor tellus.  Donec pretium posuere tellus.  Proin quam nisl, tincidunt et,
mattis eget, convallis nec, purus.  Cum sociis natoque penatibus et magnis dis
parturient montes, nascetur ridiculus mus.  Nulla posuere.  Donec vitae dolor.
Nullam tristique diam non turpis.  Cras placerat accumsan nulla.  Nullam
rutrum.  Nam vestibulum accumsan nisl.


```python
def foo(bar, **kwargs):
    print("yo, this is nice!")
```

## a list

* Donec hendrerit tempor tellus.
* Nam a sapien.
* Phasellus at dui in ligula mollis ultricies.
* Mauris mollis tincidunt felis.
* Nullam rutrum.

### Yet another list
1. Nunc aliquet, augue nec adipiscing interdum, lacus tellus malesuada massa,
   quis varius mi purus non odio.
2. Donec hendrerit tempor tellus. 
3. Nunc aliquet, augue nec adipiscing interdum, lacus tellus malesuada massa,
   quis varius mi purus non odio.

