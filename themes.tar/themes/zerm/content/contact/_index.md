+++
title="contact"
description="a basic demo of zola. Does it work?"

[extra]
date=2019-03-26
+++

# some links

- [zola, the static site generator written in rust](https://getzola.org)
- [source code for zerm](https://github.com/ejmg/zerm)
- [Terminal, the theme zerm was derived from](https://github.com/panr/hugo-theme-terminal)
- [Terminimal, another theme for zola based on Terminal](https://github.com/pawroman/zola-theme-terminimal)
