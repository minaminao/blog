+++
title = "about"
path = "about"

[extra]
date = 2019-03-21
+++

Yet another theme for yet another static site generator; that said, I hope you
like it.
